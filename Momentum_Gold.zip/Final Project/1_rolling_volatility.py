import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# read future price data of gold
data = pd.read_csv(r'/Users/xiaozhezhang/Documents/BU MSMFT Fall 23/MF_703_Programming_in_Finance/MF703_Programming_in_Math_Finance/Final Project/Input/Gold_num.csv')

# calculate the daily return of the close price
data['Returns'] = data['close'].pct_change()

window_sizes = [30, 60, 90, 180]

for window_size in window_sizes:
    # calculate the standard deviation (volatility) over a period of time
    data[f'Volatility_{window_size}'] = data['Returns'].rolling(window=window_size).std()


# Convert 'time' column to datetime format
data['time'] = pd.to_datetime(data['time'])

# Set 'time' as the index
data.set_index('time', inplace=True)

fig, ax1 = plt.subplots(figsize=(12, 6))

# Plot the 'close' prices
ax1.plot(data['close'], label='Close Price', color='b')
ax1.set_ylabel('close', color='b')
ax1.tick_params('y', colors='b')

# Create a second y-axis
ax2 = ax1.twinx()

# Plot the volatility
colors = ['r', 'g', 'y', 'c']  # Define a list of colors for the different lines
for window_size, color in zip(window_sizes, colors):
    ax2.plot(data[f'Volatility_{window_size}'], label=f'{window_size}-day Volatility', color=color)

ax2.set_ylabel('Volatility', color='r')
ax2.tick_params('y', colors='r')

# Format the x-axis to display years
years = mdates.YearLocator(5)   # every year
years_fmt = mdates.DateFormatter('%Y')
ax1.xaxis.set_major_locator(years)
ax1.xaxis.set_major_formatter(years_fmt)

plt.title('Gold Trend and Volatility')
fig.tight_layout()

# Add a legend for both y-axes
lines, labels = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax2.legend(lines + lines2, labels + labels2, loc='upper left')

# save the plot to output folder
output_dir = r'/Users/xiaozhezhang/Documents/BU MSMFT Fall 23/MF_703_Programming_in_Finance/MF703_Programming_in_Math_Finance/Final Project/Output'
plt.savefig(os.path.join(output_dir, 'Gold_Trend_Volatility.png'))


