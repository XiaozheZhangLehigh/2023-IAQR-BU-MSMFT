import pandas as pd
import talib
import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os


data = pd.read_csv(r"/Users/xiaozhezhang/Documents/BU MSMFT Fall 23/MF_703_Programming_in_Finance/MF703_Programming_in_Math_Finance/Final Project/Input/Gold_num.csv")
data['time'] = pd.to_datetime(data['time']) 
data.set_index('time', inplace=True) 

# initialize parameters
initial_balance = 100000  # initial balance
margin_ratio = 0.1  # margin ratio of futures
commission_rate = 0.001  # transaction fee
contract_multiplier = 100  # contract multiplier of futures
balance_usage_ratio = 0.2  # balance usage ratio
# balance_usage_ratio / margin_ratio = leverage_ratio
trade_times = 0
right_times = 0
accumulated_earnings = 0
accumulated_losses = 0

# initialize account information
current_balance = initial_balance
frozen_balance = 0
open_positions = {'Direction':'No_Position'}  # current position records
order_records = []  # order records 
account_values = []  # account values record

# create a output folder 
output_folder = r"/Users/xiaozhezhang/Documents/BU MSMFT Fall 23/MF_703_Programming_in_Finance/MF703_Programming_in_Math_Finance/Final Project/Output"

############################### signal generation ###############################
def calculate_signal(data):
    data_copy = data.copy()  
    data_copy['SMA_short'] = data_copy['close'].rolling(window=100).mean()
    data_copy['SMA_long'] = data_copy['close'].rolling(window=300).mean()

    # MACD
    data_copy['MACD'], data_copy['Signal'], _ = talib.MACD(data_copy['close'], fastperiod=12, slowperiod=26, signalperiod=9)

    # Bollinger Bands
    data_copy['20d_ma'] = data_copy['close'].rolling(window=20).mean()
    data_copy['upper_band'] = data_copy['20d_ma'] + 2 * data_copy['close'].rolling(window=20).std()
    data_copy['lower_band'] = data_copy['20d_ma'] - 2 * data_copy['close'].rolling(window=20).std()

    if (
        data_copy['SMA_short'].iloc[-1] > data_copy['SMA_long'].iloc[-1] and

        data_copy['close'].iloc[-1] > data_copy['upper_band'].iloc[-1] and
        data_copy['MACD'].iloc[-1] > 0
    ):
        # if 1. 100 day moving average (Short-term) crosses above 300 day moving average (long-term), 
        # and if 2. the latest close price is above the upper band of bollinger bands, 
        # and if 3. the latest MACD value is above 0, 
        # then generate buy signal
        return "Long"
    elif (
        data_copy['SMA_short'].iloc[-1] < data_copy['SMA_long'].iloc[-1] and

        data_copy['close'].iloc[-1] < data_copy['lower_band'].iloc[-1] and
        data_copy['MACD'].iloc[-1] < 0
    ):
        # if 1. 100 day moving average (Short-term) crosses below 300 day moving average (long-term), 
        # and if 2. the latest close price is below the lower band of bollinger bands, 
        # and if 3. the latest MACD value is below 0, 
        # then generate selling signal    
        return "Short"
    else:
        return "No_Signal_Update"


############################### initializing open position ###############################
def open_position(window_data, signal):
    global current_balance, frozen_balance, open_positions, order_records, trade_times, right_times, accumulated_earnings, accumulated_losses

    # calculate buying position size
    # 1. extract the latest price
    latest_price = window_data['close'].iloc[-1]
    # 2. Calculate how many lots can be bought, rounding down to the nearest whole number 计算能买多少手，向下取整数
    # (balance usage ratio * latest balance) / (margin ratio * contract multiplier * latest price)
    # explaination: (contract multiplier * latest price) represents the total value of one lot of futures, which is equivalent to the turnover (trading volume), but the term turnover will be confused with the actual margin spent and needs to be explained
    # (margin ratio * contract multiplier * latest price) represents the margin required to be frozen for one lot of futures, so that the exchange can rest assured
    # it represents a large amount of turnover, but only a small amount of cash is actually used for freezing and guaranteeing, and the ratio between the two is the source of leverage
    # therefore, the number of lots that can be bought is the total amount of cash that can be used divided by the margin required to be frozen for one lot of futures, rounded down to the nearest whole number
    position_size = math.floor( (balance_usage_ratio * current_balance) / (margin_ratio * contract_multiplier * latest_price) )
    # once the number of lots is calculated, calculate how much margin is frozen based on the number of lots just calculated
    # lots * (margin ratio * contract multiplier * latest price), equals how much cash is frozen as margin for this opening
    frozen_balance = position_size * (margin_ratio * contract_multiplier * latest_price)
    # current balance minus frozen balance is the balance of the account, and it is reload to the latest cash
    current_balance -= frozen_balance  # minus the frozen balance from the current balance 

    # update the current open positions record 
    open_positions = {
        'Symbol': 'Gold',
        'PositionSize': position_size,
        'AveragePrice': latest_price,
        'Direction': signal
    }

    # record the order placing information
    order_records.append({
        'DateTime': window_data.index[-1],
        'Action': 'Open_Position',
        'Symbol': 'Gold',
        'Price': latest_price,
        'Quantity': position_size,
        'Direction': signal
    })

############################### initializing close position ###############################
def close_position(window_data):
    global current_balance, frozen_balance, open_positions, order_records, trade_times, right_times, accumulated_earnings, accumulated_losses

    # calculate profit or loss
    # calculate the profit or loss of latest/current closing position
    # (latest price - average price) * position lots(size) * contract multiplier, 
    # take closing long position as an example, it is equivalent to: 
    # (position lots * [contract multiplier * latest price]) - (position lots * [contract multiplier * average openning price])
    # so this is the difference in turnover of the closing position lots at the opening and closing moments
    # compared with the opening, lots * (margin ratio * contract multiplier * latest price), and the difference is that there is no margin ratio
    # because the profit or loss comes from the difference in turnover, the margin is unchanged, and it will be unfrozen when closing the position
    # the margin is just to ensure that you can use leverage to work with a large turnover, which is the source of leverage profit/loss
    # the calculation of the handling fee is the same
    # it is [handling fee ratio * turnover], not multiplied by margin
    # it can be understood in this way: the trasaction fee is one of the costs of profit or loss, since the profit or loss has been magnified by leverage, the cost should be magnified by leverage, so that it is fair

    if open_positions['Direction'] == "Long":
        profit_loss = (latest_price - open_positions['AveragePrice']) * open_positions['PositionSize']  * contract_multiplier
        profit_loss -= commission_rate * (frozen_balance / margin_ratio)
    elif open_positions['Direction'] == "Short":
        profit_loss = (open_positions['AveragePrice'] - latest_price) * open_positions['PositionSize']  * contract_multiplier
        profit_loss -= commission_rate * (frozen_balance / margin_ratio)
    else:
        profit_loss = 0

    # the new current balance after closing the position = the old remaining cash + the unfrozen funds + the profit or loss of the position
    #  to protect the interests of the exchange, please note that the profit or loss is deducted from the remaining cash of the old account, without affecting the frozen funds,

    current_balance = current_balance + frozen_balance + profit_loss

    # to prevent the profit or loss from affecting the calculation of the real-time net value, clear the value of the frozen margin variable after closing the position
    frozen_balance = 0

    # update the open postions record
    open_positions = {
        'Symbol': 'Gold',
        'PositionSize': 0,
        'AveragePrice': 0,
        'Direction': 'No_Position'
    }
    # record order info 
    order_records.append({
        'DateTime': window_data.index[-1],
        'Action': 'Close_Position',
        'Symbol': 'Gold',
        'Price': latest_price,
        'Quantity': open_positions['PositionSize'],
        'ProfitLoss': profit_loss,
        'Direction': open_positions['Direction']
    })


    # update trading time profit and loss
    if profit_loss>0:
        right_times += 1
        accumulated_earnings += profit_loss
    else:
        accumulated_losses += profit_loss
    trade_times += 1


############################### plot account values ###############################
def plot_account_values(df, output_folder):

    datetime = np.array(df['DateTime'])
    net_balance = np.array(df['NetBalance'])
    net_price = np.array(df['NetPrice'])
    direction = np.array(df['Direction'])

    fig, ax = plt.subplots()

    # plot NetBalance and NetPrice curves
    ax.plot(datetime, net_balance, label='Strategy Return (SR))', color='black', linewidth=0.7 )
    ax.plot(datetime, net_price, label='Gold Return (GR)', color='blue', linewidth=0.7)

    # note the last value of NetBalance and NetPrice
    last_balance = np.array(df['StrategyReturn'])[-1]
    last_price = np.array(df['GoldReturn'])[-1]
    # ax.text(0.98, 0.95, f'Current NAB: {last_balance:.2f}\nCurrent NAP: {last_price:.2f}',
    #         transform=ax.transAxes, color='black', ha='right', va='top', fontsize=10)
    # label the last balance value on the plot
    plt.annotate(f'Current SR {last_balance:.2f}', 
             (df['DateTime'].iloc[-1], df['NetBalance'].iloc[-1]), 
             xytext=(-10, -10), textcoords='offset points', 
             ha='right', va='top', fontsize=10,
             bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))

    plt.annotate(f'Current GR: {last_price:.2f}', 
             (df['DateTime'].iloc[-1], df['NetPrice'].iloc[-1]), 
             xytext=(-10, -10), textcoords='offset points', 
             ha='right', va='top', fontsize=10,
             bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))

    # fill the area between NetBalance and NetPrice curves
    for i in range(len(datetime)):
        if direction[i] == 'Long':
            rect = mpatches.Rectangle((datetime[i], ax.get_ylim()[0]),
                                      width=pd.Timedelta(minutes=1), height=ax.get_ylim()[1],
                                      color='red', alpha=0.03)
            ax.add_patch(rect)
        elif direction[i] == 'Short':
            rect = mpatches.Rectangle((datetime[i], ax.get_ylim()[0]),
                                      width=pd.Timedelta(minutes=1), height=ax.get_ylim()[1],
                                      color='green', alpha=0.03)
            ax.add_patch(rect)

    ax.xaxis_date()
    fig.autofmt_xdate()
    ax.set_title('Strategy Return and Gold Return Over Time\nred:Long position  green:Short position  Other:No position')
    ax.set_xlabel('Time')
    ax.set_ylabel('Values')
    ax.legend(loc='upper left')
    
    #plt.show()
    output_path = os.path.join(output_folder, 'account_values_plot.png')
    plt.savefig(output_path)
    plt.close()  

    return output_path  # Return the path to the saved plot

############################### strategy evaluation metrics ################################
def strategy_evaluation(df, trade_times, right_times, output_folder):
   
    evaluation_table = pd.DataFrame()

    # calculate strategy return

    trading_strategy_return = df['StrategyReturn'].iloc[-1]
    gold_return = df['GoldReturn'].iloc[-1]
    evaluation_table.loc['Strategy Return', 'Value'] = round(trading_strategy_return, 3)

    # calculate annualized return
    # len(df['NetBalance']) 11894 trading_days 17104
    #start_date = df['DateTime'].iloc[0]
    #end_date = df['DateTime'].iloc[-1]
    #trading_days = (end_date - start_date).days
    net_value = df_account_values['NetBalance'].iloc[-1] / df_account_values['NetBalance'].iloc[0]
    gold_net_value = df_account_values['NetPrice'].iloc[-1] / df_account_values['NetPrice'].iloc[0]
    annual_return = net_value ** (252 / len(df_account_values)) - 1
    gold_annual_return = gold_net_value ** (252 / len(df_account_values)) - 1
    evaluation_table.loc['Strategy Annualized Return', 'Value'] = round(annual_return, 3)
    #benchmark_annualized_return = round((round(df['NetPrice'].iloc[-1], 3) / df['NetPrice'].iloc[0]) ** (252 / len(df_account_values)) - 1, 3) 

    evaluation_table.loc['Gold Return', 'Value'] = round(gold_return, 3)
    evaluation_table.loc['Gold Annualized Return', 'Value'] = round(gold_annual_return, 3)

    # calculate excess return: need to choose the benchmark, here is relative to the gold future price
    excess_return = df['NetBalance'].iloc[-1] - df['NetPrice'].iloc[-1]
    evaluation_table.loc['Excess Return', 'Value'] = round(excess_return, 3)

 
    daily_returns = df['NetBalance'].pct_change() 
    volatility = daily_returns.std() * np.sqrt(252)  
    evaluation_table.loc['Volatility', 'Value'] = round(volatility, 3)


    risk_free_rate = 0.03  
    sharpe_ratio = (annual_return - risk_free_rate) / volatility
    evaluation_table.loc['Sharpe Ratio', 'Value'] = round(sharpe_ratio, 3)

    
    df_account_values['max_Drawdown'] = df_account_values['NetBalance'] / df_account_values['NetBalance'].cummax() - 1
    
    drawdown = df_account_values['max_Drawdown'].min()
    evaluation_table.loc['Max Drawdown', 'Value'] = round(drawdown, 3)

    evaluation_table.loc['Trade Times', 'Value'] = round(trade_times)

    win_rate = round(right_times / trade_times, 3)
    evaluation_table.loc['Win Rate', 'Value'] = win_rate

    if right_times == 0:
        profit_loss_ratio = 0 
    elif (trade_times-right_times) == 0:
        profit_loss_ratio = (accumulated_earnings/right_times)
    else:
        profit_loss_ratio = (accumulated_earnings/right_times) / (accumulated_losses/(trade_times-right_times))
    evaluation_table.loc['Profit/Loss Ratio', 'Value'] = round(abs(profit_loss_ratio), 3)


    plt.figure(figsize=(12, 6))
    plt.subplot(2, 1, 1)

    ####
    # plt.plot(df['DateTime'].to_numpy(), df['NetBalance'].to_numpy(), label='Strategy Net Value')
    # plt.title('Strategy NetBalance Curve')

    ###

    plt.plot(df['DateTime'].to_numpy(), df['StrategyReturn'].to_numpy(), label='Strategy Return')
    plt.title('Strategy Return Curve')

    # note the last value of NetBalance
    last_balance = df['StrategyReturn'].iloc[-1]
    # label the last balance value on the plot
    # plt.text(df['DateTime'].iloc[-1], df['NetBalance'].iloc[-1], f'Current NetBalance: {last_balance:.2f}',
    #          color='black', ha='right', va='bottom', fontsize=10)
    plt.annotate(f'Current StrategyReturn: {last_balance:.2f}', 
             (df['DateTime'].iloc[-1], df['NetBalance'].iloc[-1]), 
             xytext=(-10, -10), textcoords='offset points', 
             ha='right', va='top', fontsize=10,
             bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.plot(df['DateTime'].to_numpy(), df_account_values['max_Drawdown'].to_numpy(), label='Max Drawdown')
    plt.title('Max Drawdown Curve')
    # lable the max drawdown value on the plot
    # plt.text(df['DateTime'].iloc[-1], df_account_values['Drawdown'].iloc[-1], f'Max Drawdown: {drawdown:.2f}',
    #          color='black', ha='right', va='bottom', fontsize=10)

    plt.annotate(f'Max Drawdown: {drawdown:.2f}', 
                 (df['DateTime'].iloc[-1], df_account_values['max_Drawdown'].iloc[-1]), 
                 xytext=(-10, -10), textcoords='offset points', 
                 ha='right', va='top', fontsize=10,
                 bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))


    plt.legend()

    output_path1 = os.path.join(output_folder, 'strategy_evaluation_curve.png')
    plt.savefig(output_path1)
    plt.close()

    plt.figure(figsize=(10, 5))
    plt.axis('off')  
    plt.table(cellText=evaluation_table.reset_index().values,
              colLabels=['Metric', 'Value'],
              cellLoc='center',
              loc='center')
    plt.title('Strategy Evaluation Table')

    #plt.show()
    
    output_path2 = os.path.join(output_folder, 'strategy_evaluation_table.png')
    plt.savefig(output_path2)
    plt.close()

    return evaluation_table, df_account_values


############################### backtesting ################################
window_size = 500
for i in range(window_size, len(data)):
    window_data = data.iloc[i - window_size:i]

    signal = calculate_signal(window_data)

    if (signal == "Long" or signal == "Short") and open_positions['Direction'] == "No_Position":
        open_position(window_data, signal)
        #print(open_positions['Direction'],account_values[-1],round(current_balance),round(frozen_balance),round(current_balance+frozen_balance))
        #print("Open when No Position") # open position when no postion 

    elif signal == "Long" and open_positions['Direction'] == "Short":
        close_position(window_data)  # close old position first 
        open_position(window_data, signal)  # then open new position 
        #print(open_positions['Direction'],account_values[-1],round(current_balance),round(frozen_balance),round(current_balance+frozen_balance))
        #print("Close Short and Open Long") # close short and open long position

    elif signal == "Short" and open_positions['Direction'] == "Long":
        close_position(window_data)  # close old position first 
        open_position(window_data, signal)  # then open new position 
        #print(open_positions['Direction'],account_values[-1],round(current_balance),round(frozen_balance),round(current_balance+frozen_balance))
        #print("Close Long Open Short") # close long and open short position

    else:
        pass

    latest_price = window_data['close'].iloc[-1]

    if open_positions['Direction'] == "Long":
        profit_loss = (latest_price - open_positions['AveragePrice']) * open_positions['PositionSize'] * contract_multiplier
    elif open_positions['Direction'] == "Short":
        profit_loss = (open_positions['AveragePrice'] - latest_price) * open_positions['PositionSize'] * contract_multiplier
    else:
        profit_loss = 0
    
    total_balance = current_balance + frozen_balance + profit_loss

    account_values.append({
        'DateTime': window_data.index[-1],
        'TotalBalance': total_balance,
        'CurrentBalance': current_balance,
        'FrozenBalance': frozen_balance,
        'ProfitLoss': profit_loss,
        'LatestPrice':latest_price,
        'Direction':open_positions['Direction'],
        'NetBalance':round(total_balance/initial_balance,2),
        'NetPrice':round(latest_price/data['close'][window_size],2),
        'StrategyReturn':round(total_balance/initial_balance-1,2),
        'GoldReturn':round(latest_price/data['close'][window_size]-1,2)
    })
    
    # if open_positions['Direction'] == "Long" or open_positions['Direction'] == "Short"  :
    #     print(open_positions['Direction'],latest_price,round(total_balance),round(current_balance),round(frozen_balance),round(profit_loss),profit_loss / frozen_balance)
    # else:
    #     print(open_positions['Direction'],latest_price,round(total_balance),round(current_balance),round(frozen_balance),round(profit_loss),0)


    # using info from real-time account balance
    # Force liquidation 
    # When the remaining cash (used as maintenance margin) plus profits and losses fall below zero, 
    # # it indicates that there isn't enough cash to maintain the margin for the held positions, necessitating forced liquidation
     
    if current_balance + profit_loss < 0:
        close_position(window_data) # Regardless of the direction, need to force liquidate, wait for the next signal, and open positions when there are no holdings
        #print(open_positions['Direction'],account_values[-1],round(current_balance),round(frozen_balance),round(current_balance+frozen_balance))
        #print("Margin Call")

    # Stop_Loss
    # Stop loss is for position, so need to look at the ratio of floating losses to frozen margin when there is a position
    #if (open_positions['Direction'] == "Long" or open_positions['Direction'] == "Short") and profit_loss / frozen_balance < - 0.3:
    #    close_position(window_data) 
        #print(open_positions['Direction'],account_values[-1],round(current_balance),round(frozen_balance),round(current_balance+frozen_balance))
    #    print("Stop_Loss")

############################### complete backtesting ################################


############################### strategy evaluation ################################
df_account_values = pd.DataFrame(account_values)

# save the account values table to a csv file to output folder
df_account_values.to_csv(os.path.join(output_folder, 'account_values_table.csv'), index=False)
df_account_values.to_csv(r"/Users/xiaozhezhang/Documents/BU MSMFT Fall 23/MF_703_Programming_in_Finance/MF703_Programming_in_Math_Finance/Final Project/Output/account_values_table.csv", index=False)

# # create the drawdown table


plot_account_values(df_account_values, output_folder)
evaluation_result,_= strategy_evaluation(df_account_values, trade_times, right_times, output_folder)
# print(evaluation_result)

_, df_strat_evalue = strategy_evaluation(df_account_values, trade_times, right_times, output_folder)
#df_strat_evalue.to_csv(os.path.join(output_folder, 'strategy_evaluation_account_table.csv'), index=False)

# group df_strat_evalue['Drawdown'] by year 
df_strat_evalue['DateTime'] = pd.to_datetime(df_strat_evalue['DateTime'])

# Calculate drawdown for each day
df_strat_evalue['Year'] = df_strat_evalue['DateTime'].dt.year
df_strat_evalue['MaxDrawdown'] = df_strat_evalue.groupby('Year')['max_Drawdown'].transform('min')

# Create a table with the year and the corresponding maximum drawdown
drawdown_table = df_strat_evalue.groupby('Year')['MaxDrawdown'].min().reset_index()

# filter out the years with drawdown less than -0.5 for significance check
# drawdown_table = drawdown_table[drawdown_table['MaxDrawdown'] < -0.5]

# # Print the drawdown table
# print(drawdown_table)

drawdown_table.to_csv(os.path.join(output_folder, 'yearly_max_drawdown_table.csv'), index=False)


print("Task Complete!")